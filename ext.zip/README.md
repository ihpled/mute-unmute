# Mute/Unmute Gnome extension.

Add Mute/Unmute functionality to audio output icon, remembering unmuted volume level
